## Pokedex

An interactive pokedex that lets the user catch and remove wild pokemon, and displays their statistics such as type, abilities, move, and so on.

## https://www.andres-espitia.com/pokedex/
